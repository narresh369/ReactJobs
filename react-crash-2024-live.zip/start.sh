#!/bin/bash

# Start JSON Server on port 8000 in the background
# npm run server &

# Build the React app
# npm run build

# Serve the production build using 'npx serve'
# npx serve -s dist -l 3000
# node server.js
# npm run dev
npm run start
