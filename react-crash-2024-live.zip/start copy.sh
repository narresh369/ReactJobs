#!/bin/bash

# Start your server
npm run server &

# Start your dev process
npm run dev
